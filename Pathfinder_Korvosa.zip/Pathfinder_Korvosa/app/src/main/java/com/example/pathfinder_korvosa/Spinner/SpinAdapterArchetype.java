package com.example.pathfinder_korvosa.Spinner;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.pathfinder_korvosa.R;

import java.util.ArrayList;

public class SpinAdapterArchetype extends ArrayAdapter<SpinnerItemArchetype> {

    public SpinAdapterArchetype(Context context, ArrayList<SpinnerItemArchetype> SpinListArchetype) {
        super(context, 0, SpinListArchetype);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_spinneritem, parent, false);
        }
        TextView textViewFlag = convertView.findViewById(R.id.spin_item);

        SpinnerItemArchetype currentItem = getItem(position);

        if (currentItem != null) {
            textViewFlag.setText(currentItem.getmSpinnerItemsArchetype());
        }

        return convertView;
    }
}
