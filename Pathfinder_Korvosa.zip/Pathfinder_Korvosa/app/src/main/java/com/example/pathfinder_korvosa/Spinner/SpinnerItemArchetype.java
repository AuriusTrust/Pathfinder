package com.example.pathfinder_korvosa.Spinner;

public class SpinnerItemArchetype {

    private String mSpinnerItemsArchetype;

    public SpinnerItemArchetype(String spinerItems){
        mSpinnerItemsArchetype = spinerItems;
    }

    public String getmSpinnerItemsArchetype() {
        return mSpinnerItemsArchetype;
    }

    public void setmSpinnerItemsArchetype(String mSpinnerItemsArchetype) {
        this.mSpinnerItemsArchetype = mSpinnerItemsArchetype;
    }
}
