package com.example.pathfinder_korvosa.DataBase;

import android.content.Context;


public class PersonnageDAO extends DAOBase{
    public static final String TABLE_NAME = "Personnage";
    public static final String KEY = "id";
    public static final String PSEUDO = "pseudo";
    public static final String RACE = "race";
    public static final String CLASSE = "classe";
    public static final String ARCHETYPE = "archetype";
    public static final String RELIGION = "religion";
    public static final String LEVEL = "level";
    public static final String FORCE = "force";
    public static final String DEXTERITE = "dexterite";
    public static final String CONSTITUTION = "constitution";
    public static final String INTELLIGENCE = "intelligence";
    public static final String SAGESSE = "sagesse";
    public static final String CHARISME = "charisme";
    public static final String PV = "pv";

    public static final String TABLE_CREATE = "CREATE TABLE " + TABLE_NAME + " (" +
            KEY +
            PSEUDO + " TEXT, " +
            RACE + " TEXT, " +
            CLASSE + " TEXT, " +
            ARCHETYPE + " TEXT, " +
            RELIGION + " TEXT, " +
            LEVEL + " INTEGER, " +
            FORCE + " INTEGER, " +
            DEXTERITE + " INTEGER, " +
            CONSTITUTION + " INTEGER, " +
            INTELLIGENCE + " INTEGER, " +
            SAGESSE + " INTEGER, " +
            CHARISME + " INTEGER, " +
            PV + " INTEGER);";

    public static final String TABLE_DROP =  "DROP TABLE IF EXISTS " + TABLE_NAME + ";";

    /**
     * @param m le personnage à ajouter à la base
     */
    public void ajouter(Personnage m) {
        // CODE
    }

    /**
     * @param id l'identifiant du personnage à supprimer
     */
    public void supprimer(long id) {
        // CODE
    }

    /**
     * @param m le personnage modifié
     */
    public void modifier(Personnage m) {
        // CODE
    }

    /**
     * @param id l'identifiant du personnage à récupérer
     */
    public void Personnage_selectionner(long id) {
        // CODE
    }

    public PersonnageDAO(Context pContext) {
        super(pContext);
    }

    /*@Dao
    public interface UserDao {

        @Query("SELECT * FROM user")
        List<User> getAll();

        @Query("SELECT * FROM user where first_name LIKE  :firstName AND last_name LIKE :lastName")
        User findByName(String firstName, String lastName);

        @Query("SELECT COUNT(*) from user")
        int countUsers();

        @Insert
        void insertAll(User... users);

        @Delete
        void delete(User user);
    }*/
}
