package com.example.pathfinder_korvosa.DataBase;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.pathfinder_korvosa.utilitaire.User;

import java.util.List;

@Dao
public interface UserDAO {

    @Query("SELECT * FROM personnage")
    List<User> getAll();

    @Query("SELECT * FROM personnage where Pseudo LIKE  :pseudo AND Race LIKE :race AND Classe LIKE :classe AND Archetype LIKE :archetype ")
    User findByName(String pseudo, String race, String classe, String archetype, String religion);

    @Query("SELECT COUNT(*) from personnage")
    int countUsers();

    @Insert
    void insertAll(User... users);

    @Delete
    void delete(User user);

}
