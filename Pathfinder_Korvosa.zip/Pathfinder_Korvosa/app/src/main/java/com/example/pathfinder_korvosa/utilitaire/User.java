package com.example.pathfinder_korvosa.utilitaire;

public class User {
    private String Pseudo;
    private String Nom;
    private String Prenom;
    private String Mail;

    public String getPseudo() {
        return Pseudo;
    }

    public void setPseudo(String pseudo) {
        Pseudo = pseudo;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String firstname) {
        Nom = firstname;
    }

    public String getPrenom() {
        return Prenom;
    }

    public void setPrenom(String prenom) {
        Prenom = prenom;
    }

    public String getMail() {
        return Mail;
    }

    public void setMail(String mail) {
        Mail = mail;
    }

    @Override
    public String toString() {
        return "User{" +
                "mPseudo='" + Pseudo + '\'' +
                //"mNom='" + Nom + '\'' +
                //"prenom='" + Prenom + '\'' +
                //"mail='" + Mail + '\'' +
                '}';
    }
}
