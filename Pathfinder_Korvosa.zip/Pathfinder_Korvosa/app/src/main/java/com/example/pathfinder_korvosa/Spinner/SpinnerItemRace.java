package com.example.pathfinder_korvosa.Spinner;

public class SpinnerItemRace {

    private String mSpinnerItemsRace;

    public SpinnerItemRace(String spinerItems){
        mSpinnerItemsRace = spinerItems;
    }

    public String getmSpinnerItemsRace() {
        return mSpinnerItemsRace;
    }

    public void setmSpinnerItemsRace(String mSpinnerItemsRace) {
        this.mSpinnerItemsRace = mSpinnerItemsRace;
    }
}
