package com.example.pathfinder_korvosa.controller;

import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pathfinder_korvosa.R;

public class GameActivity extends AppCompatActivity {

    private EditText jetD20;
    private EditText bonusTouch;
    private EditText BBA;

    private CheckBox magique;
    private RadioButton humain;
    private RadioButton mortVivant;
    private RadioButton extMal;
    private RadioButton autre;
    private CheckBox visee;
    private CheckBox boutPortant;
    private CheckBox arbaleteTueuseHumain;
    private CheckBox carreauxTueursHumain;
    private CheckBox SortAspectFaucon;
    private CheckBox SortArcGravite;
    private EditText bonusSuppToucher;

    private int toucher = 0;
    private int degat = 0;
    private int i = 0;

    // 1 - FILE PURPOSE
    private static final String FILENAME = "tripBook.txt";
    private static final String FOLDERNAME = "bookTrip";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        System.out.println("GameActivity::onCreate()");



        definition();

        bonusSuppToucher.setText("0");

        Button btnValiderToucher_btn = (Button) findViewById(R.id.btnValidationToucher);
        btnValiderToucher_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                clicValider();

                TextView ResultatTouch = (TextView) findViewById(R.id.ResultatTouch_text);
                TextView ResultatDegat = (TextView) findViewById(R.id.ResultatDegat_text);

                ResultatTouch.setText("Attaque : " + String.valueOf(toucher) );
                ResultatDegat.setText("   Degat :  " + String.valueOf(degat));
                toucher = 0;
                degat = 0;

            }
        });
        Button btnReset_btn = (Button) findViewById(R.id.btnReset);
        btnReset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Nouvelle valeur Reset -----------------------------------------------" + i);
                if (i <= 5) {
                    Toast.makeText(GameActivity.this, "Salut t qui ? ça sert à rien ça pour le moment", Toast.LENGTH_LONG).show();
                    System.out.println("Nouvelle valeur Reset -----------------------------------------------" + i);
                    i = i + 1;
                    System.out.println("Nouvelle valeur Reset -----------------------------------------------" + i);
                } else if (i == 6) {
                    Toast.makeText(GameActivity.this, "C'est en développement touche pas ! Stop !", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 7) {
                    Toast.makeText(GameActivity.this, "Tu va tout casser mongolo !", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 8) {
                    Toast.makeText(GameActivity.this, "Complot du Sheliax", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 9) {
                    Toast.makeText(GameActivity.this, "A mort la reine !", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 10) {
                    Toast.makeText(GameActivity.this, "Longue vie à Konrad !!", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 11) {
                    Toast.makeText(GameActivity.this, "Et l'argent à Abadar", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 12) {
                    Toast.makeText(GameActivity.this, "Le MJ il est beau", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 13) {
                    Toast.makeText(GameActivity.this, "Hélas c'est la fin de l'Easter Egg...", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 14) {
                    Toast.makeText(GameActivity.this, "Odin est plus beau que le MJ", Toast.LENGTH_LONG).show();
                    i++;
                } else if (i == 15) {
                    Toast.makeText(GameActivity.this, "Fin.", Toast.LENGTH_LONG).show();
                    i = 0;
                }

            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();

        System.out.println("GameActivity::onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        System.out.println("GameActivity::onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        System.out.println("GameActivity::onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        System.out.println("GameActivity::onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        System.out.println("GameActivity::onDestroy()");
    }

    protected void definition() {
        jetD20 = (EditText) findViewById(R.id.d20_Edit);
        bonusTouch = (EditText) findViewById(R.id.touch_edit);
        BBA = (EditText) findViewById(R.id.BBA_Edit);

        magique = (CheckBox) findViewById(R.id.magique_checkBox);
        humain = (RadioButton) findViewById(R.id.humain_radio1);
        mortVivant = (RadioButton) findViewById(R.id.mortVivant_radio2);
        extMal = (RadioButton) findViewById(R.id.ExterieurMal_radio3);
        autre = (RadioButton) findViewById(R.id.autre_radio4);
        visee = (CheckBox) findViewById(R.id.visee_sw);
        boutPortant = (CheckBox) findViewById(R.id.aBoutPortant_sw);
        arbaleteTueuseHumain = (CheckBox) findViewById(R.id.arbaleteTueuseHumain_sw);
        carreauxTueursHumain = (CheckBox) findViewById(R.id.carreauxTueursHumain_sw);
        SortAspectFaucon = (CheckBox) findViewById(R.id.aspectFaucon_sw);
        SortArcGravite = (CheckBox) findViewById(R.id.arcGravite_sw);
        bonusSuppToucher = (EditText) findViewById(R.id.bonus_supplementaire);
    }

    public void clicValider() {
        String getJetD20 = jetD20.getText().toString();
        String getBBA = BBA.getText().toString();
        String getBonusTouch = bonusTouch.getText().toString();
        String getBonusSup = bonusSuppToucher.getText().toString();


        if (getJetD20.matches("") || getBBA.matches("") || getBonusSup.matches("")) {
            jetD20.setText("0");
            bonusTouch.setText("0");
            BBA.setText("0");
            bonusSuppToucher.setText("0");
            return;
        }
        if (!getJetD20.matches("")) {
            toucher = Integer.valueOf(getJetD20);
            System.out.println("Nouvelle valeur de toucher ----------------------------- d20------------------" + toucher);
        }
        if (!getBonusTouch.matches("")) {
            toucher = toucher + Integer.valueOf(getBonusTouch);
            System.out.println("Nouvelle valeur de toucher ----------------------------- toucher ------------------" + toucher);
        }
        if (!getBonusSup.matches("")) {
            toucher = toucher + Integer.valueOf(getBonusSup);
            System.out.println("Nouvelle valeur de toucher ----------------------------- supp ------------------" + toucher);
        }


        if (magique.isChecked()) {
            toucher = toucher + 2;
            degat = degat + 2;
            System.out.println("magique");
        }

        if (visee.isChecked()) {
            if (Integer.valueOf(getBBA) < 4) {
                toucher = toucher - 1;
                degat = degat + 2;
                System.out.println("Rang 1 : " + toucher + " et " + degat);
            }
            if ((Integer.valueOf(getBBA) >= 4) && ((Integer.valueOf(getBBA) < 8))) {
                toucher = toucher - 2;
                degat = degat + 4;
                System.out.println("Rang 2 : " + toucher + " et " + degat);
            }
            if ((Integer.valueOf(getBBA) >= 8) && ((Integer.valueOf(getBBA) < 12))) {
                toucher = toucher - 3;
                degat = degat + 6;
                System.out.println("Rang 3 : " + toucher + " et " + degat);
            }
            if ((Integer.valueOf(getBBA) >= 12) && ((Integer.valueOf(getBBA) < 16))) {
                toucher = toucher - 4;
                degat = degat + 8;
                System.out.println("Rang 4 : " + toucher + " et " + degat);
            }
            if ((Integer.valueOf(getBBA) >= 16) && (Integer.valueOf(getBBA) < 20)) {
                toucher = toucher - 5;
                degat = degat + 10;
                System.out.println("Rang 5 : " + toucher + " et " + degat);
            }
            if (Integer.valueOf(getBBA) >= 20) {
                toucher = toucher - 6;
                degat = degat + 12;
                System.out.println("Rang 6 : " + toucher + " et " + degat);
            }
        }

        if (boutPortant.isChecked()) {
            toucher = toucher + 1;
            degat = degat + 1;
            System.out.println("boutPortant" + toucher);
        }

        if (!arbaleteTueuseHumain.isChecked() && (!carreauxTueursHumain.isChecked())) {

            System.out.println("Pas tueur d'humain" + toucher + "0d6");
        }

        if (arbaleteTueuseHumain.isChecked() && (!carreauxTueursHumain.isChecked())) {
            toucher = toucher + 2;
            degat = degat + 2;
            System.out.println("arbaleteTueuseHumain" + toucher + "2d6");
        }

        if (carreauxTueursHumain.isChecked() && (!arbaleteTueuseHumain.isChecked())) {
            toucher = toucher + 2;
            degat = degat + 2;
            System.out.println("carreauxTueursHumain soit : " + toucher + " et " + degat);
        }

        if ((arbaleteTueuseHumain.isChecked()) && (carreauxTueursHumain.isChecked())) {
            toucher = toucher + 4;
            degat = degat + 4;

            System.out.println("arbalète et carreaux tueurs d'humain, soit : " + toucher + " et " + degat + " et 4d6");
        }

        if (SortAspectFaucon.isChecked()) {
            toucher = toucher + 1;
            System.out.println("SortAspectFaucon et " + toucher + " et Critique: ");
        }

        if (SortArcGravite.isChecked()) {
            System.out.println("SortArcGravite 2d8");
        }

        if (humain.isChecked()) {
            toucher = toucher + 4;
            degat = degat + 4;
            System.out.println("Humain Radio");
        }

        if (mortVivant.isChecked()) {
            toucher = toucher + 2;
            degat = degat + 2;
            System.out.println("Mort Vivant Radio");
        }

        if (extMal.isChecked()) {
            toucher = toucher + 4;
            degat = degat + 4;
            System.out.println("Extérieur Mal Radio");
        }

        if (autre.isChecked()) {
            System.out.println("Autre Radio");
        }
    }
}