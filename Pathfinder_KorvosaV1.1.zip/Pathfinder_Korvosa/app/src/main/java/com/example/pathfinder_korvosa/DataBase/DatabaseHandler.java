package com.example.pathfinder_korvosa.DataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {
    public static final String PERSONNAGE_TABLE_NAME = "PERSONNAGE";

    public static final String PERSONNAGE_KEY = "id";
    public static final String PSEUDO = "pseudo";
    public static final String RACE = "race";
    public static final String CLASSE = "classe";
    public static final String ARCHETYPE = "archetype";
    public static final String RELIGION = "religion";
    public static final String LEVEL = "level";
    public static final String FORCE = "force";
    public static final String DEXTERITE = "dexterite";
    public static final String CONSTITUTION = "constitution";
    public static final String INTELLIGENCE = "intelligence";
    public static final String SAGESSE = "sagesse";
    public static final String CHARISME = "charisme";
    public static final String PV = "pv";




    public static final String PERSONNAGE_TABLE_CREATE =
            "CREATE TABLE " + PERSONNAGE_TABLE_NAME + " (" +
                    PERSONNAGE_KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    PSEUDO + " TEXT, " +
                    RACE + " TEXT, " +
                    CLASSE + " TEXT, " +
                    ARCHETYPE + " TEXT, " +
                    RELIGION + " TEXT, " +
                    LEVEL + " INTEGER, " +
                    FORCE + " INTEGER, " +
                    DEXTERITE + " INTEGER, " +
                    CONSTITUTION + " INTEGER, " +
                    INTELLIGENCE + " INTEGER, " +
                    SAGESSE + " INTEGER, " +
                    CHARISME + " INTEGER, " +
                    PV + " INTEGER);";

    public static final String PERSONNAGE_TABLE_DROP = "DROP TABLE IF EXISTS " + PERSONNAGE_TABLE_NAME + ";";

    //private MySQLite maBaseSQLITE;
    //private SQLiteDatabase db;

    public DatabaseHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(PERSONNAGE_TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(PERSONNAGE_TABLE_DROP);
        onCreate(db);
    }


}