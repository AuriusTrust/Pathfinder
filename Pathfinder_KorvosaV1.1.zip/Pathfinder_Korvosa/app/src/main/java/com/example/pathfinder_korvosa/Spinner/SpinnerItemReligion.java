package com.example.pathfinder_korvosa.Spinner;

public class SpinnerItemReligion {

    private String mSpinnerItemsReligion;

    public SpinnerItemReligion(String spinerItemsReligion){
        mSpinnerItemsReligion = spinerItemsReligion;
    }

    public String getmSpinnerItemsReligion() {
        return mSpinnerItemsReligion;
    }

    public void setmSpinnerItemsReligion(String mSpinnerItemsReligion) {
        this.mSpinnerItemsReligion = mSpinnerItemsReligion;
    }
}
