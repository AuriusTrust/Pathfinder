package com.example.pathfinder_korvosa.controller.CreaPage5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.pathfinder_korvosa.R;
import com.example.pathfinder_korvosa.controller.CreaPage6.CreationPersonnageEquipementActivity;

import static com.example.pathfinder_korvosa.controller.MainActivity.CREATION_PERSONNAGE_ACTIVITY_REQUEST_CODE;

public class CreationPersonnageSortActivity extends AppCompatActivity implements View.OnClickListener {

    private Button mNext2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creation_personnage_sorts);

        System.out.println("CreationPersonnageSortActivity::onCreate()");

        mNext2 = (Button) findViewById(R.id.btnValidationCreaPersoStat);


        mNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent creationPersonnageActivityIntent = new Intent(CreationPersonnageSortActivity.this, CreationPersonnageEquipementActivity.class);
                startActivityForResult(creationPersonnageActivityIntent, CREATION_PERSONNAGE_ACTIVITY_REQUEST_CODE);
            }
        });
    }

    @Override
    public void onClick(View v) {

        int responseIndex = (int) v.getTag();

    }

    @Override
    protected void onStart() {
        super.onStart();

        System.out.println("CreationPersonnageActivity::onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        System.out.println("CreationPersonnageActivity::onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        System.out.println("CreationPersonnageActivity::onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        System.out.println("CreationPersonnageActivity::onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        System.out.println("CreationPersonnageActivity::onDestroy()");
    }
}

