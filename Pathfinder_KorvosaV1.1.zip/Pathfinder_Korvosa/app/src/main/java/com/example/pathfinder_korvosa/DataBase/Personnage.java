package com.example.pathfinder_korvosa.DataBase;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.util.ArrayList;

@Entity
public class Personnage {

    @PrimaryKey
    private long id;

    private String Pseudo;
    private String Race;
    private String Classe;
    private String Archetype;
    private String Religion;


    private int LvL;
    private int For;
    private int Dex;
    private int Con;
    private int Int;
    private int Sag;
    private int Char;
    private int PV;

    //ArrayList Equipement;


    public Personnage(long id, String Pseudo, String Race, String Classe, String Religion, int LvL, int For, int Dex, int Con, int Int, int Sag, int Char, int PV){
        super();
        this.id = id;
        this.Pseudo = Pseudo;
        this.Race = Race;
        this.Classe = Classe;
        this.Religion = Religion;
        this.LvL = LvL;
        this.For = For;
        this.Dex = Dex;
        this.Con = Con;
        this.Int = Int;
        this.Sag = Sag;
        this.Char = Char;
        this.PV = PV;
    }



    public String getNom() {
        return Pseudo;
    }

    public void setNom(String nom) {
        Pseudo = nom;
    }

    public String getRace() {
        return Race;
    }

    public void setRace(String race) {
        Race = race;
    }

    public String getClasse() {
        return Classe;
    }

    public void setClass(String aClasse) {
        Classe = aClasse;
    }

    public String getArchetype() {
        return Archetype;
    }

    public void setArchetype(String archetype) {
        Archetype = archetype;
    }

    public String getReligion() {
        return Religion;
    }

    public void setReligion(String religion) {
        Religion = religion;
    }

    public int getLvL() {
        return LvL;
    }

    public void setLvL(int lvL) {
        LvL = lvL;
    }

    public int getFor() {
        return For;
    }

    public void setFor(int aFor) {
        For = aFor;
    }

    public int getDex() {
        return Dex;
    }

    public void setDex(int dex) {
        Dex = dex;
    }

    public int getCon() {
        return Con;
    }

    public void setCon(int con) {
        Con = con;
    }

    public int getInt() {
        return Int;
    }

    public void setInt(int anInt) {
        Int = anInt;
    }

    public int getSag() {
        return Sag;
    }

    public void setSag(int sag) {
        Sag = sag;
    }

    public int getChar() {
        return Char;
    }

    public void setChar(int aChar) {
        Char = aChar;
    }

    public int getPV() {
        return PV;
    }

    public void setPV(int PV) {
        this.PV = PV;
    }

    @Override
    public String toString() {
        return "Personnage{" +
                "Nom='" + Pseudo + '\'' +
                ", Race='" + Race + '\'' +
                ", Classe='" + Classe + '\'' +
                ", Religion='" + Religion + '\'' +
                ", LvL=" + LvL +
                ", For=" + For +
                ", Dex=" + Dex +
                ", Con=" + Con +
                ", Int=" + Int +
                ", Sag=" + Sag +
                ", Char=" + Char +
                ", PV=" + PV +
                '}';
    }
}
