package com.example.pathfinder_korvosa.Spinner;

public class SpinnerItemClasse {

    private String mSpinnerItemsClasse;

    public SpinnerItemClasse(String spinerItemsClasse){
        mSpinnerItemsClasse = spinerItemsClasse;
    }

    public String getmSpinnerItemsClasse() {
        return mSpinnerItemsClasse;
    }

    public void setmSpinnerItemsClasse(String mSpinnerItemsClasse) {
        this.mSpinnerItemsClasse = mSpinnerItemsClasse;
    }
}
