package com.example.pathfinder_korvosa.controller.CreaPage1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pathfinder_korvosa.R;
import com.example.pathfinder_korvosa.Spinner.SpinAdapter;
import com.example.pathfinder_korvosa.Spinner.SpinAdapterArchetype;
import com.example.pathfinder_korvosa.Spinner.SpinAdapterClasse;
import com.example.pathfinder_korvosa.Spinner.SpinAdapterReligion;
import com.example.pathfinder_korvosa.Spinner.SpinnerItemArchetype;
import com.example.pathfinder_korvosa.Spinner.SpinnerItemClasse;
import com.example.pathfinder_korvosa.Spinner.SpinnerItemRace;
import com.example.pathfinder_korvosa.Spinner.SpinnerItemReligion;
import com.example.pathfinder_korvosa.controller.CreaPage2.CreationPersonnageStatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static com.example.pathfinder_korvosa.controller.MainActivity.CREATION_PERSONNAGE_STAT_ACTIVITY_REQUEST_CODE;

public class CreationPersonnageActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<SpinnerItemRace> mSpinnerListRace;
    private ArrayList<SpinnerItemClasse> mSpinnerListClasse;
    private ArrayList<SpinnerItemArchetype> mSpinnerListArchetype;
    private ArrayList<SpinnerItemReligion> mSpinnerListReligion;

    private SpinAdapter mAdapterRace;
    private SpinAdapterClasse mAdapterClasse;
    private SpinAdapterArchetype mAdapterArchetype;
    private SpinAdapterReligion mAdapterReligion;

    private Button mNext;

    private String simpleFileName = "creationPersonnage.txt";

    private Button mTest;
    int i = 0;

    String SpinRaceItemSelected = null;
    String SpinClasseItemSelected = null;
    String SpinArchetypeItemSelected = null;
    String SpinReligionItemSelected = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creation_personnage);

        System.out.println("CreationPersonnageActivity::onCreate()");

        initListRace();
        initListClasse();
        initListArchetype();
        initListReligion();

        final Spinner spinnerMenuRace = findViewById(R.id.SpinnerRace);
        mAdapterRace = new SpinAdapter(this, mSpinnerListRace);
        spinnerMenuRace.setAdapter(mAdapterRace);

        final Spinner spinnerMenuClasse = findViewById(R.id.SpinnerClasse);
        mAdapterClasse = new SpinAdapterClasse(this,mSpinnerListClasse);
        spinnerMenuClasse.setAdapter(mAdapterClasse);

        final Spinner spinnerMenuArchetype = findViewById(R.id.SpinnerArchetype);
        mAdapterArchetype = new SpinAdapterArchetype(this, mSpinnerListArchetype);
        spinnerMenuArchetype.setAdapter(mAdapterArchetype);

        final Spinner spinnerMenuReligion = findViewById(R.id.SpinnerReligion);
        mAdapterReligion = new SpinAdapterReligion(this, mSpinnerListReligion);
        spinnerMenuReligion.setAdapter(mAdapterReligion);

        spinnerMenuRace.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinnerItemRace clickedItem = (SpinnerItemRace) parent.getItemAtPosition(position);
                SpinRaceItemSelected = clickedItem.getmSpinnerItemsRace();
                Toast.makeText(CreationPersonnageActivity.this, SpinRaceItemSelected+ " selected",Toast.LENGTH_SHORT).show();
                if(clickedItem.getmSpinnerItemsRace()!=" "){
                    spinnerMenuClasse.setVisibility(View.VISIBLE);
                    spinnerMenuRace.setBackgroundColor(0xFFFFFF);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        spinnerMenuClasse.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinnerItemClasse clickedItem = (SpinnerItemClasse) parent.getItemAtPosition(position);
                SpinClasseItemSelected = clickedItem.getmSpinnerItemsClasse();
                Toast.makeText(CreationPersonnageActivity.this, SpinClasseItemSelected+ " selected",Toast.LENGTH_SHORT).show();
                if(clickedItem.getmSpinnerItemsClasse()!=" "){
                    spinnerMenuArchetype.setVisibility(View.VISIBLE);
                    spinnerMenuClasse.setBackgroundColor(0xFFFFFF);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        spinnerMenuArchetype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinnerItemArchetype clickedItem = (SpinnerItemArchetype) parent.getItemAtPosition(position);
                SpinArchetypeItemSelected = clickedItem.getmSpinnerItemsArchetype();
                Toast.makeText(CreationPersonnageActivity.this, SpinArchetypeItemSelected+ " selected",Toast.LENGTH_SHORT).show();
                if(clickedItem.getmSpinnerItemsArchetype()!=" "){
                    spinnerMenuReligion.setVisibility(View.VISIBLE);
                    spinnerMenuArchetype.setBackgroundColor(0xFFFFFF);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        spinnerMenuReligion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SpinnerItemReligion clickedItem = (SpinnerItemReligion) parent.getItemAtPosition(position);
                SpinReligionItemSelected = clickedItem.getmSpinnerItemsReligion();
                Toast.makeText(CreationPersonnageActivity.this, SpinReligionItemSelected+ " selected",Toast.LENGTH_SHORT).show();
                if(clickedItem.getmSpinnerItemsReligion()!=" "){
                    spinnerMenuReligion.setBackgroundColor(0xFFFFFF);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mNext = (Button) findViewById(R.id.btnValidationCreaPerso);

        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveData();


                //readData();

                Intent creationPersonnageActivityIntent = new Intent(CreationPersonnageActivity.this, CreationPersonnageStatActivity.class);
                startActivityForResult(creationPersonnageActivityIntent, CREATION_PERSONNAGE_STAT_ACTIVITY_REQUEST_CODE);




            }
        });

        mTest = (Button) findViewById(R.id.btnTest);

        mTest.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


                if (i==0){
                    saveData();
                    i++;
                }else if (i==1){
                    readData();
                    i=0;

                }
            }

        });





    }

    private void initListRace(){
        mSpinnerListRace = new ArrayList<>();
        mSpinnerListRace.add(new SpinnerItemRace(" "));
        mSpinnerListRace.add(new SpinnerItemRace("Elfe "));
        mSpinnerListRace.add(new SpinnerItemRace("Nain "));
        mSpinnerListRace.add(new SpinnerItemRace("Humain "));
        mSpinnerListRace.add(new SpinnerItemRace("Orc "));
        mSpinnerListRace.add(new SpinnerItemRace("Demi-Elfe "));
        mSpinnerListRace.add(new SpinnerItemRace("Gnomes "));
        mSpinnerListRace.add(new SpinnerItemRace("Halfelins "));
    }
    private void initListClasse(){
        mSpinnerListClasse = new ArrayList<>();
        mSpinnerListClasse.add(new SpinnerItemClasse(" "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Rodeur "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Barbare "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Barde "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Druide "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Ensorceleur "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Guerrier "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Magicien "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Moine "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Paladin "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Prêtre "));
        mSpinnerListClasse.add(new SpinnerItemClasse("Roublard "));
    }
    private void initListArchetype(){
        mSpinnerListArchetype = new ArrayList<>();
        mSpinnerListArchetype.add(new SpinnerItemArchetype(" "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("Urbain "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("of "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("your "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("classe "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("Demi-Elfe "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("Gnomes "));
        mSpinnerListArchetype.add(new SpinnerItemArchetype("Halfelins "));
    }
    private void initListReligion(){
        mSpinnerListReligion = new ArrayList<>();
        mSpinnerListReligion.add(new SpinnerItemReligion(" "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Abadar "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Iomedae "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Ragaciel "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Konrad "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Aurius "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Le Vert Geant tout nul "));
        mSpinnerListReligion.add(new SpinnerItemReligion("Les fags de la tribu du feu "));
    }

    private void saveData() {
        String dataRace = SpinRaceItemSelected;
        String dataClasse = SpinClasseItemSelected;
        String dataArchetype = SpinArchetypeItemSelected;
        String dataReligion = SpinReligionItemSelected;
        try {
            // Open Stream to write file.
            FileOutputStream out = this.openFileOutput(simpleFileName, MODE_PRIVATE);
            // Ghi dữ liệu.
            out.write(dataRace.getBytes());
            out.write(dataClasse.getBytes());
            out.write(dataArchetype.getBytes());
            out.write(dataReligion.getBytes());
            out.close();
            Toast.makeText(this,"File saved!",Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this,"Error:"+ e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    private void readData() {
        try {
            // Open stream to read file.
            FileInputStream in = this.openFileInput(simpleFileName);

            BufferedReader br= new BufferedReader(new InputStreamReader(in));

            StringBuilder sb= new StringBuilder();
            String s= null;
            while((s= br.readLine())!= null)  {
                sb.append(s).append("\n");
            }
            System.out.println(SpinRaceItemSelected);
            Toast.makeText(this,sb.toString(),Toast.LENGTH_SHORT).show();
            TextView TestSelectionSpinner = (TextView) findViewById(R.id.testView);
            TestSelectionSpinner.setVisibility(View.VISIBLE);
            TestSelectionSpinner.setText(sb.toString());

        } catch (Exception e) {
            Toast.makeText(this,"Error:"+ e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }









    @Override
    public void onClick(View v) {

        int responseIndex = (int) v.getTag();


    }



    @Override
    protected void onStart() {
        super.onStart();

        System.out.println("CreationPersonnageActivity::onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        System.out.println("CreationPersonnageActivity::onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        System.out.println("CreationPersonnageActivity::onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        System.out.println("CreationPersonnageActivity::onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        System.out.println("CreationPersonnageActivity::onDestroy()");
    }
}
